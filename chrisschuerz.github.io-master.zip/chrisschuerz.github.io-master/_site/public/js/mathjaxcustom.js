MathJax.Hub.Config({
          "HTML-CSS": {
            styles: {
              ".MathJax .mo, .MathJax .mi": {color: "black ! important"}
            }
          }
        });