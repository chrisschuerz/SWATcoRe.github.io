# Knitr-Hyde

This is a skeleton/tutorial for a Jekyll-powered blog based on the [Lanyon](http://lanyon.getpoole.com) theme by [@mdo](https://twitter.com/mdo), customized for R-bloggers with the help of Yihui Xie's <a href = "https://github.com/yihui/knitr-jekyll">knitr-jekyll</a>.  It's intended for first-time Jekyll-users who want to blog about R.

For instructions consult the [site itself](https:homerhanumat.github.io/knitr-lanyon).